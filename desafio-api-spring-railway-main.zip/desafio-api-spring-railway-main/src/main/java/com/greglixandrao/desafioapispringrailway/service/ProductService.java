package com.greglixandrao.desafioapispringrailway.service;

import com.greglixandrao.desafioapispringrailway.domain.model.Product;

public interface ProductService extends CrudService<Long, Product> {
}
